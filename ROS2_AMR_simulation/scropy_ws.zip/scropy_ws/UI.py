#!bin/usr/bin/env python3 
import time
import sys,os,signal,subprocess
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton

procs={}
CMS ={
    "gazebo" : ["ros2", "launch", "scropy", 
                   "launch_sim.launch.py" ],
    "slamtool_box" : ["ros2", "launch", "slam_toolbox", "online_async_launch.py", "slam_params_file:=./src/scropy/config/mapper_params_online_async.yaml",  "use_sim_time:=true"],
    "navigation": ["ros2", "launch", "scropy", "navigation.launch.py", "use_sim_time:=true"],
  
    
}

NODE_NAME =["gazebo","slamtool_box","navigation"]


def start(name):
    p = procs.get(name)
    if p and p.poll() is   None:
        return
    procs[name] = subprocess.Popen(
        CMS[name],
        stdout= subprocess.DEVNULL, stderr =subprocess.DEVNULL,
        preexec_fn=os.setsid
    )
def stop(name):
    p = procs.get(name)
    if not p:
        print(f"{name} not running")
        return
    print(f"Stopping {name}...")
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGINT)
        try:
            p.wait(timeout=2)
        except subprocess.TimeoutExpired:
            print(f"{name} not stopping, forcing kill.")
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
    except Exception as e:
        print(f"Error stopping {name}: {e}")
    procs.pop(name, None)





        
def gazebo_left():
    for pat in ["gzserver", "gazebo", "gzclient"]:
        subprocess.run(["pkill", "f", pat], stdout = subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL,check=False
        )
        
def stop_all():
    # 1. Stop Gazebo FIRST
    stop("gazebo")
    time.sleep(1.0)

    # 2. Stop SLAM Toolbox
    stop("slam")
    time.sleep(1.0)

    # 3. Stop Nav2
    stop("nav2")
    time.sleep(1.0)

    # 4. Any remaining nodes
    for node in NODE_NAME:
        stop(node)
        time.sleep(0.5)

    # 5. Kill any remaining Gazebo processes just in case
    gazebo_left()

    
def main():
    app = QApplication(sys.argv)
    w = QWidget(); w.setWindowTitle("launch_panel")
    lay = QVBoxLayout(w)
    btn = QPushButton("gazebo_launch")
    btn.clicked.connect(lambda: start("gazebo"));  lay.addWidget(btn)
    
    btn = QPushButton("slamtoolbox_launch")
    btn.clicked.connect(lambda: start("slamtool_box"));  lay.addWidget(btn)
    
    btn = QPushButton("navigation_launch")
    btn.clicked.connect(lambda: start("navigation"));  lay.addWidget(btn)

    btn = QPushButton("Ctrl+c")
    btn.clicked.connect(stop_all); lay.addWidget(btn)
    


    w.setLayout(lay)
    w.show()
    





    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
	
	

        
        
