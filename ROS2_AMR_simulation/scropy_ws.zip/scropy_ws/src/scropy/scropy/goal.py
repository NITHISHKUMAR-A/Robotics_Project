import rclpy 
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.duration import Duration
import math


class Nav2Commander(Node):
    def __init__(self):
        super().__init__('nav2_commander')
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')


    def send_goal(self, x, y, theta_deg):
        goal_msg = NavigateToPose.Goal()

        goal_msg.pose.header.frame_id= 'map'

        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y


        qz = math.sin(math.radians(theta_deg) / 2.0)
        qw = math.cos(math.radians(theta_deg) / 2.0)
        goal_msg.pose.pose.orientation.z = qz
        goal_msg.pose.pose.orientation.w = qw

        self._action_client.wait_for_server()
        self.get_logger().info(f'Sending goal: x={x}, y={y}, theta={theta_deg}°')


        return self._action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)


    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f'Remaining distance: {feedback.distance_remaining:.2f} m')


def main(args=None):
    rclpy.init(args=args)
    commander = Nav2Commander()

    # -------------------------
    # First Goal
    # -------------------------
    future1 = commander.send_goal(4.0, 3.0, 0)
    rclpy.spin_until_future_complete(commander, future1)
    result1 = future1.result()

    if result1.status == 4:  # STATUS_ABORTED
        commander.get_logger().error('First goal was aborted')
    elif result1.status != 3:  # STATUS_SUCCEEDED
        commander.get_logger().warn(f'First goal failed with status code: {result1.status}')
    else:
        commander.get_logger().info('First goal succeeded!')

        # -------------------------
        # Wait for User Permission
        # -------------------------
        user_input = input("Proceed to next goal? (y/n): ").strip().lower()
        if user_input == 'y':
            # -------------------------
            # Second Goal
            # -------------------------
            future2 = commander.send_goal(2.0, 3.0, 90)  # Change this to your second goal
            rclpy.spin_until_future_complete(commander, future2)
            result2 = future2.result()

            if result2.status == 4:
                commander.get_logger().error('Second goal was aborted')
            elif result2.status != 3:
                commander.get_logger().warn(f'Second goal failed with status code: {result2.status}')
            else:
                commander.get_logger().info('Second goal succeeded!')
        else:
            commander.get_logger().info('Second goal canceled by user.')

    commander.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

