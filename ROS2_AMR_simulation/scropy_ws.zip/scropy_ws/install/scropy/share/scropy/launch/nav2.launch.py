from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')
    
    # Define the remapping rule as a list of tuples
    remap_cmd_vel = [('/cmd_vel', '/diff_cont/cmd_vel_unstamped')]

    navigation_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_bringup_dir, 'launch', 'navigation_launch.py')
        ),
        # The remappings argument is part of the IncludeLaunchDescription action
        # not the main LaunchDescription or a generic Action class.
        remappings=remap_cmd_vel
    )

    return LaunchDescription([
        navigation_launch,
    ])